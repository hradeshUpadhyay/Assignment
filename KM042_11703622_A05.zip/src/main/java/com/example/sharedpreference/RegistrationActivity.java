package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    public static final String USER_CREDENTIALS ="user_credentials" ;
    public static final String USERNAME ="username" ;
    public static final String PASSWORD0 = "password0";
    public static final String STATE = "state";
    EditText e1,e2,e3;
    boolean check;
Button bn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        e1=findViewById(R.id.username);
        e2=findViewById(R.id.password);
        e3=findViewById(R.id.confirmpassword);
    }

    public void Register(View view) {

        String s1=e1.getText().toString();
        String s2=e2.getText().toString();
        String s3=e3.getText().toString();

        if (s1.isEmpty())
        {
            e1.setError("Username");
        }
        else  if (s2.isEmpty())
        {
            e2.setError("password");
        }
        else  if (s3.isEmpty())
        {
            e3.setError("confirm password");
        }
        else if (!(s2.equals(s3)))
        {
            Toast.makeText(this, "Password not matched", Toast.LENGTH_SHORT).show();
        }
        else
        {
            SharedPreferences.Editor editor=getSharedPreferences(USER_CREDENTIALS,MODE_PRIVATE).edit();
            editor.putString(USERNAME,s1);
            editor.putString(PASSWORD0,s2);
            editor.putBoolean(STATE,check);
            editor.apply();
            Toast.makeText(this, "Signup successful", Toast.LENGTH_SHORT).show();

            Intent intent=new Intent(RegistrationActivity.this,MainActivity.class);
            startActivity(intent);
            RegistrationActivity.this.finish();
        }
    }
}
