package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText ee1,ee2;
TextView newAccount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ee1=findViewById(R.id.userUsername);
        ee2=findViewById(R.id.userPassword);
        newAccount=findViewById(R.id.newAccount);

        SharedPreferences preferences=getSharedPreferences(RegistrationActivity.USER_CREDENTIALS,MODE_PRIVATE);
        Boolean checking= preferences.getBoolean(RegistrationActivity.STATE,false);
        if (checking==true)
        {
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
            MainActivity.this.finish();
        }
        newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

    public void login(View view) {
        String s1=ee1.getText().toString();
        String s2=ee2.getText().toString();

        SharedPreferences preferences=getSharedPreferences(RegistrationActivity.USER_CREDENTIALS,MODE_PRIVATE);
        String user= preferences.getString(RegistrationActivity.USERNAME,"hradesh");
        String pass= preferences.getString(RegistrationActivity.PASSWORD0,"hradesh");



        if (s1.equals(user) && s2.equals(pass))
        {
            SharedPreferences.Editor editor=getSharedPreferences(RegistrationActivity.USER_CREDENTIALS,MODE_PRIVATE).edit();
            editor.putBoolean(RegistrationActivity.STATE,true);
            editor.apply();
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
            MainActivity.this.finish();
        }
        else
        {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }
}
